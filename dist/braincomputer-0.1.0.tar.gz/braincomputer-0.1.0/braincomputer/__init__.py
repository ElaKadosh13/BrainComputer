from .client import upload_thought
from .server import run_server
from .web import run_webserver
